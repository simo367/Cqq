<?php

namespace Pterodactyl\Http\Controllers\Server;

use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Traits\Controllers\JavascriptInjection;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class SubDomainController extends Controller
{
    use JavascriptInjection;

    /**
     * @var \Prologue\Alerts\AlertsMessageBag
     */
    protected $alert;

    /**
     * @var \Pterodactyl\Contracts\Repository\SettingsRepositoryInterface
     */
    protected $settings;

    /**
     * SubDomainController constructor.
     * @param AlertsMessageBag $alert
     * @param SettingsRepositoryInterface $settings
     */
    public function __construct(AlertsMessageBag $alert, SettingsRepositoryInterface $settings)
    {
        $this->alert = $alert;
        $this->settings = $settings;
    }

    /**
     * @param Request $request
     * @return View
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function index(Request $request): View
    {
        $server = $request->attributes->get('server');
        $this->authorize('view-subdomain', $server);
        $this->setRequest($request)->injectJavascript();

        $domains = [];
        $allDomains = DB::table('subdomain_manager_domains')->get();
        $subdomains = DB::table('subdomain_manager_subdomains')->where('server_id', '=', $server->id)->get();
        $allocation = DB::table('allocations')->where('id', '=', $server->allocation_id)->get();

        foreach ($allDomains as $domain) {
            $egg_ids = explode(',', $domain->egg_ids);

            foreach ($egg_ids as $egg_id) {
                if ($server->egg_id == $egg_id) {
                    $domains[] = $domain;
                }
            }
        }

        foreach ($subdomains as $key => $subdomain) {
            foreach ($domains as $domain) {
                if ($subdomain->domain_id == $domain->id) {
                    $subdomains[$key]->domain = $domain->domain;
                }
            }
        }

        return view('server.subdomain', ['domains' => $domains, 'subdomains' => $subdomains, 'ip_alias' => $allocation[0]->ip_alias]);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Illuminate\Validation\ValidationException
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function create(Request $request)
    {
        $server = $request->attributes->get('server');
        $this->authorize('view-subdomain', $server);

        $this->validate($request, [
            'subdomain' => 'required|min:0|max:32',
            'domain' => 'required|integer'
        ]);

        $subdomain = strtolower(trim(strip_tags($request->input('subdomain'))));
        $domain_id = (int) $request->input('domain');

        $domain = DB::table('subdomain_manager_domains')->where('id', '=', $domain_id)->get();
        if (count($domain) < 1) {
            $this->alert->danger('Domain not found.')->flash();
            return redirect()->route('server.subdomain', $server->uuidShort);
        }

        $protocol = unserialize($domain[0]->protocol);
        $protocol = $protocol[$server->egg_id];

        $type = unserialize($domain[0]->protocol_types);
        $type = empty($type[$server->egg_id]) || !isset($type[$server->egg_id]) ? 'tcp' : $type[$server->egg_id];

        $subdomainCount = DB::table('subdomain_manager_subdomains')->where('server_id', '=', $server->id)->get();
        if (count($subdomainCount) >= $this->settings->get('settings::subdomain::max_subdomain', 1)) {
            $this->alert->danger('You can create maximum ' . $this->settings->get('settings::subdomain::max_subdomain', 1) . ' Subdomain.')->flash();
            return redirect()->route('server.subdomain', $server->uuidShort);
        }
		
		if(preg_match("/^[a-zA-Z0-9]+$/", $subdomain) != 1) {
            $this->alert->danger('Invalid domain name format. The domain only contains: [a-z] [A-Z] [0-9]')->flash();

            return redirect()->route('server.subdomain', $server->uuidShort);
        }

        $subdomainIsset = DB::table('subdomain_manager_subdomains')->where('domain_id', '=', $domain_id)->where('subdomain', '=', $subdomain)->get();
        if (count($subdomainIsset) > 0) {
            $this->alert->danger('This subdomain is already taken: ' . $subdomain)->flash();
            return redirect()->route('server.subdomain', $server->uuidShort);
        }

        $allocation = DB::table('allocations')->where('id', '=', $server->allocation_id)->get();

        try {
            $key = new \Cloudflare\API\Auth\APIKey(
                $this->settings->get('settings::subdomain::cf_email', ''),
                $this->settings->get('settings::subdomain::cf_api_key', '')
            );
            $adapter = new \Cloudflare\API\Adapter\Guzzle($key);
            $zones = new \Cloudflare\API\Endpoints\Zones($adapter);
            $dns = new \Cloudflare\API\Endpoints\DNS($adapter);

            $zoneID = $zones->getZoneID($domain[0]->domain);
        } catch (\Exception $e) {
            $this->alert->danger('Failed to connect to cloudflare server.')->flash();
            return redirect()->route('server.subdomain', $server->uuidShort);
        }

        if (empty($protocol)) {
            $subdomain_all = $subdomain . '.' . $domain[0]->domain;

            $result = $dns->listRecords($zoneID, 'CNAME', $subdomain_all)->result;

            if (count($result) > 0) {
                $this->alert->danger('This subdomain is already taken: ' . $subdomain)->flash();
                return redirect()->route('server.subdomain', $server->uuidShort);
            }

            $data = array(
                'type' => 'CNAME',
                'name' => $subdomain,
    			'content' => $allocation[0]->ip_alias,
    			'proxiable' => false,
    			'proxied' => false,
    			'ttl' => 120
            );
        } else {
            $subdomain_all = $protocol . '._' . $type . '.' . $subdomain . '.' . $domain[0]->domain;

            $result = $dns->listRecords($zoneID, 'SRV', $subdomain_all)->result;

            if (count($result) > 0) {
                $this->alert->danger('This subdomain is already taken: ' . $subdomain)->flash();
                return redirect()->route('server.subdomain', $server->uuidShort);
            }

            $data = array(
                'type' => 'SRV',
                'data' => array(
                    "name" => $subdomain,
                    "ttl" => 120,
                    "service" => $protocol,
                    "proto" => "_" . $type,
                    "weight" => 1,
                    "port" => $allocation[0]->port,
                    "priority" => 1,
                    "target" => $allocation[0]->ip_alias,
                )
            );
        }

        try {
            if ($dns->addRecord($zoneID, $data) !== true) {
                $this->alert->danger('Failed to create subdomain.')->flash();
                return redirect()->route('server.subdomain', $server->uuidShort);
            }
        } catch (\Exception $e) {
            $this->alert->danger('Failed to create subdomain.')->flash();
            return redirect()->route('server.subdomain', $server->uuidShort);
        }

        DB::table('subdomain_manager_subdomains')->insert([
            'server_id' => $server->id,
            'domain_id' => $domain_id,
            'subdomain' => $subdomain,
            'port' => $allocation[0]->port,
            'record_type' => empty($protocol) ? 'CNAME' : 'SRV'
        ]);

        $this->alert->success('You have successfully created new Subdomain.')->flash();
        return redirect()->route('server.subdomain', $server->uuidShort);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    public function delete(Request $request)
    {
        $server = $request->attributes->get('server');
        $this->authorize('view-subdomain', $server);

        $id = (int) $request->input('id', '');

        $subdomain = DB::table('subdomain_manager_subdomains')->where('id', '=', $id)->where('server_id', '=', $server->id)->get();
        if (count($subdomain) < 1) {
            return response()->json(['success' => false, 'error' => 'Subdomain not found.']);
        }

        $domain = DB::table('subdomain_manager_domains')->where('id', '=', $subdomain[0]->domain_id)->get();
        if (count($domain) < 1) {
            return response()->json(['success' => false, 'error' => 'Domain not found.']);
        }

        $protocol = unserialize($domain[0]->protocol);
        $protocol = $protocol[$server->egg_id];

        $type = unserialize($domain[0]->protocol_types);
        $type = empty($type[$server->egg_id]) || !isset($type[$server->egg_id]) ? 'tcp' : $type[$server->egg_id];

        try {
            $key = new \Cloudflare\API\Auth\APIKey(
                $this->settings->get('settings::subdomain::cf_email', ''),
                $this->settings->get('settings::subdomain::cf_api_key', '')
            );
            $adapter = new \Cloudflare\API\Adapter\Guzzle($key);
            $zones = new \Cloudflare\API\Endpoints\Zones($adapter);
            $dns = new \Cloudflare\API\Endpoints\DNS($adapter);

            $zoneID = $zones->getZoneID($domain[0]->domain);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => 'Failed to connect to cloudflare server.']);
        }

        if (empty($protocol)) {
            $subdomain_all = $subdomain[0]->subdomain . '.' . $domain[0]->domain;

            $result = $dns->listRecords($zoneID, 'CNAME', $subdomain_all)->result;

            if (count($result) < 1) {
                return response()->json(['success' => false, 'error' => 'Failed to delete Subdomain.']);
            }

            $recordId = $result[0]->id;
        } else {
            $subdomain_all = $protocol . '._' . $type . '.' . $subdomain[0]->subdomain . '.' . $domain[0]->domain;

            $result = $dns->listRecords($zoneID, 'SRV', $subdomain_all)->result;

            if (count($result) < 1) {
                return response()->json(['success' => false, 'error' => 'Failed to delete Subdomain.']);
            }

            $recordId = $result[0]->id;
        }

        try {
            if ($dns->deleteRecord($zoneID, $recordId) !== true) {
                return response()->json(['success' => false, 'error' => 'Failed to delete Subdomain.']);
            }
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'error' => 'Failed to delete Subdomain.']);
        }

        DB::table('subdomain_manager_subdomains')->where('id', '=', $id)->where('server_id', '=', $server->id)->delete();

        return response()->json(['success' => true]);
    }
}
